# MarketScannerAgent - Specification & Design

**Agent ID:** `market_scanner_agent`  
**File:** `finance_service/agents/market_scanner_agent.py`  
**Status:** ✅ Production-ready, actively used  
**Version:** 2.0  
**Last Updated:** 2026-03-29

---

## Overview

MarketScannerAgent is the **entry point into the trading pipeline**. It scans a configured universe of symbols organized by themes (e.g., AI, Semiconductor, Cloud, MegaCap, Hong Kong) and discovers promising candidates for further analysis.

**Key Responsibility:** Given market conditions and configuration, select a subset of symbols that warrant deeper analysis by downstream agents.

---

## Design Philosophy

```
                    ┌─────────────────────────────────┐
                    │  Configured Universe (finance.yaml) │
                    │  Organized by themes              │
                    └──────────────┬────────────────────┘
                                   │
                    ┌──────────────▼─────────────────┐
                    │  MarketScannerAgent.run()       │
                    │  - Select themes                │
                    │  - Filter by whitelist (if set) │
                    │  - Filter by liquidity          │
                    │  - Rank by composite score      │
                    │  - Limit results                │
                    └──────────────┬────────────────────┘
                                   │
                    ┌──────────────▼─────────────────┐
                    │  MARKET_SCANNED event emitted   │
                    │  payload: {symbols: [...]}      │
                    └──────────────┬────────────────────┘
                                   │
                    ┌──────────────▼─────────────────┐
                    │  Downstream agents process     │
                    │  each symbol independently     │
                    │  (DataAgent, NewsAgent, etc.)  │
                    └─────────────────────────────────┘
```

---

## Input Parameters

### `run(include_themes=None, min_liquidity=0.0, limit=10, data_agent=None)`

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `include_themes` | `List[str]` or `None` | `None` | Which themes to scan. `None` = all available themes. Example: `["AI", "Semiconductor"]` |
| `min_liquidity` | `float` | `0.0` | Minimum average daily volume threshold. Symbols below this volume are excluded. |
| `limit` | `int` | `10` | Max number of symbols to return. |
| `data_agent` | `DataAgent` or `None` | `None` | Optional DataAgent for fetching real market data for liquidity filtering and composite scoring. If `None`, filtering and ranking fall back to neutral defaults. |

### Example Calls

```python
# Scan all themes, return top 10 (default)
report = await scanner.run()

# Scan only AI and Semiconductor themes, limit to 5
report = await scanner.run(
    include_themes=["AI", "Semiconductor"],
    limit=5
)

# Scan all themes, filter low-volume symbols, return top 20 with live data
report = await scanner.run(
    min_liquidity=1_000_000,
    limit=20,
    data_agent=data_agent_instance
)
```

---

## Output (AgentReport)

### Structure

```python
{
    "agent_id": "market_scanner_agent",
    "status": "opportunity",
    "message": "Discovered 8 promising symbols.",
    "payload": {
        "symbols": ["NVDA", "PLTR", "AMD", "TSLA", "MSFT", "META", "GOOG", "AVGO"],
        "count": 8,
        "total_scanned": 25
    },
    "timestamp": "2026-03-29T14:30:00.123Z"
}
```

### Fields

| Field | Type | Description |
|-------|------|-------------|
| `agent_id` | string | Always `"market_scanner_agent"` |
| `status` | string | Always `"opportunity"` (indicates symbols found) |
| `message` | string | Summary: `"Discovered {count} promising symbols."` |
| `payload.symbols` | `List[str]` | List of selected symbol strings (e.g., `["NVDA", "PLTR", ...]`) |
| `payload.count` | int | Length of symbols list |
| `payload.total_scanned` | int | Total symbols considered before filtering/limiting |
| `timestamp` | ISO8601 | When the report was generated |

---

## Internal Processing Steps

### Step 1: Theme Selection (`_scan_by_themes()`)

```
Input: include_themes (or None for all)
  ↓
Get available themes from config
  ↓
For each selected theme:
  └─ Get symbols for that theme
  └─ Add to combined set
  ↓
[If whitelist enabled]
  └─ Intersect combined set with whitelist
  └─ (Keeps only whitelisted symbols)
  ↓
Output: Sorted list of selected symbols
```

**Example:**
```
Config themes: ["AI", "Semiconductor", "Cloud", "MegaCap", "Hong Kong"]
Input: include_themes=["AI", "Semiconductor"]

Step 1: Get AI symbols → ["NVDA", "PLTR", "UPST", "AVGO", "MSTR"]
Step 2: Get Semiconductor symbols → ["TSM", "QCOM", "AMD", "ASR", "ASML"]
Step 3: Combine → 10 symbols
Step 4: [If whitelist enabled] → Filter to only whitelisted
Output: Sorted combined list
```

---

### Step 2: Liquidity Filter (`_filter_by_liquidity()`)

**Status:** ✅ **Implemented**

Fetches real volume data for each symbol via DataAgent and excludes symbols whose average volume falls below `min_liquidity`. Falls back to returning all symbols unchanged if no DataAgent is provided or if data fetch fails (safe degradation).

```python
async def _filter_by_liquidity(self, symbols, min_liquidity, data_agent=None):
    if min_liquidity <= 0 or data_agent is None:
        return symbols  # No filtering needed

    filtered = []
    for symbol in symbols:
        report = await data_agent.run(symbol, interval="1d", use_cache=True, emit_events=False)
        if report and report.payload:
            volume_data = report.payload.get("ohlcv", {}).get("volume", [])
            if volume_data:
                avg_volume = sum(volume_data[-20:]) / len(volume_data[-20:])
                if avg_volume >= min_liquidity:
                    filtered.append(symbol)
                continue
        filtered.append(symbol)  # Include on fetch failure (safe default)
    return filtered
```

**Behaviour:**
- Without DataAgent: all symbols pass through unchanged
- With DataAgent + `min_liquidity > 0`: fetches 20-day average volume, excludes below threshold
- Fetch failure for a symbol: symbol is kept (conservative, safe default)

---

### Step 3: Symbol Ranking (`_rank_symbols()`)

**Status:** ✅ **Implemented**

Computes a composite score for each symbol using five weighted criteria. Returns symbols sorted best-first. Falls back to original order if no DataAgent is available.

**Composite Score Formula:**

| Factor | Weight | Data Source | Calculation |
|--------|--------|-------------|-------------|
| Technical | 30% | OHLCV close prices | Price momentum: `(close[-1] - close[-5]) / close[-5]` normalised |
| Momentum | 20% | OHLCV volume | Volume trend: `recent_avg / older_avg` normalised |
| Value | 20% | Fundamentals P/E | Low P/E preferred: `1 - (pe / 100)` clamped to [0,1] |
| Trend | 20% | Fundamentals Market Cap | Large-cap preference (>100B = 1.0, >10B = 0.7, else 0.4) |
| Liquidity | 10% | OHLCV average volume | `log(avg_volume) / log(10^10)` normalised |

- Each factor defaults to **neutral 0.5** if data is unavailable
- Symbols are sorted descending by composite score
- DataAgent absence: all symbols score 0.5 (equal), original order preserved

---

### Step 4: Apply Limit

```
Input: Ranked symbols list, limit=10
  ↓
Take first N symbols (up to limit)
  ↓
Output: final_selection (max length = limit)
```

---

## Configuration (finance.yaml)

### Universe Structure

```yaml
finance:
  universe:
    themes:
      - name: "AI"
        symbols:
          - NVDA
          - PLTR
          - UPST
          - AVGO
          - MSTR

      - name: "Semiconductor"
        symbols:
          - TSM
          - QCOM
          - AMD
          - ASR
          - ASML

      - name: "Cloud"
        symbols:
          - CRWD
          - DDOG
          - NET
          - MDB
          - SNOW

      - name: "MegaCap"
        symbols:
          - MSFT
          - GOOGL
          - AAPL
          - AMZN
          - META

      - name: "Hong Kong"
        symbols:
          - 0700.HK    # Tencent
          - 9988.HK    # Alibaba
          - 0941.HK    # China Mobile
          - 1398.HK    # ICBC
          - 0388.HK    # HKEx

    # Optional: Whitelist enforcement
    whitelist:
      enabled: false          # Set to true to restrict to whitelist
      symbols: []             # Only these symbols allowed when enabled
```

### Configuration API

```python
class MarketScannerAgent:
    def get_available_themes(self) -> List[str]:
        """Returns all theme names from config"""
        # Returns: ["AI", "Semiconductor", "Cloud", "MegaCap", "Hong Kong"]

    def get_symbols_by_theme(self, theme: str) -> List[str]:
        """Returns all symbols for a specific theme"""
        # get_symbols_by_theme("AI") → ["NVDA", "PLTR", "UPST", "AVGO", "MSTR"]

    def get_all_symbols(self) -> List[str]:
        """Returns entire configured universe (all symbols, deduplicated)"""

    def get_stats(self) -> Dict:
        """Returns universe statistics"""
        # Returns:
        # {
        #     "total_symbols": 25,
        #     "total_themes": 5,
        #     "themes": ["AI", "Semiconductor", "Cloud", "MegaCap", "Hong Kong"],
        #     "whitelist_enabled": false,
        #     "whitelist_count": 0
        # }
```

---

## Utility Methods

### Query Methods (Non-async)

#### `scan_theme(theme: str) -> Dict`
Get detailed info for a single theme:
```python
result = scanner.scan_theme("AI")
# Returns:
# {
#     "theme": "AI",
#     "symbols": ["NVDA", "PLTR", "UPST", "AVGO", "MSTR"],
#     "count": 5
# }
```

#### `scan_all_themes() -> Dict`
Get detailed scan of all themes:
```python
result = scanner.scan_all_themes()
# Returns:
# {
#     "AI": {"symbols": [...], "count": 5},
#     "Semiconductor": {"symbols": [...], "count": 5},
#     "Cloud": {"symbols": [...], "count": 5},
#     "MegaCap": {"symbols": [...], "count": 5},
#     "Hong Kong": {"symbols": [...], "count": 5}
# }
```

#### `validate_symbols(symbols: List[str]) -> Dict`
Check if symbols are in configured universe:
```python
result = scanner.validate_symbols(["NVDA", "INVALID", "PLTR"])
# Returns:
# {
#     "valid": ["NVDA", "PLTR"],
#     "invalid": ["INVALID"]
# }
```

#### `get_stats() -> Dict`
Get universe statistics (see Configuration API section above).

---

## Event Flow Integration

```
SchedulerAgent fires MARKET_SCAN_TRIGGER
    ↓
MainOrchestratorAgent.handle_market_scan_trigger()
    ↓
Calls: MarketScannerAgent.run(include_themes=None, limit=10, data_agent=data_agent)
    ↓
MarketScannerAgent:
    1. Scans all themes → 25 symbols
    2. Filters by liquidity (with DataAgent) → N symbols
    3. Ranks by composite score → sorted by score
    4. Applies limit → 10 symbols
    ↓
Returns AgentReport with 10 symbols
    ↓
Publishes MARKET_SCANNED event
    ↓
MainOrchestratorAgent.handle_market_scanned()
    ↓
For each symbol in payload:
    └─ Spawn DataAgent.run(symbol)
```

> **Note:** `data_agent` is currently not wired from the orchestrator. When not passed, liquidity filtering and ranking degrade gracefully (all symbols pass, original order preserved). Wiring `data_agent` in `app.py` is a pending orchestrator task.

---

## Current Status & Roadmap

| Feature | Status | Notes |
|---------|--------|-------|
| **Theme-based discovery** | ✅ Implemented | 5 themes, 25 symbols |
| **Whitelist filtering** | ✅ Implemented | Controlled by config flag |
| **Liquidity filtering** | ✅ Implemented | Requires `data_agent` parameter |
| **Symbol ranking** | ✅ Implemented | 5-factor composite scoring |
| **DataAgent wiring in orchestrator** | ⏳ Pending | Wire `data_agent` in `app.py` |
| **Structured output (scores/reasons)** | 🔮 Future | For RankingAgent phase |

---

## Design Validation Against Actual Code

### ✅ What Was Implemented

- **Theme-based organization** — Confirmed in config: AI, Semiconductor, Cloud, MegaCap, Hong Kong
- **Whitelist support** — `_whitelist_enabled` and `_whitelist_symbols` config keys
- **Liquidity filtering** — Real volume fetch via DataAgent, 20-day average
- **Composite ranking** — 5-factor scoring (technical 30%, momentum 20%, value 20%, trend 20%, liquidity 10%)
- **Output format** — AgentReport with `symbols`, `count`, `total_scanned`
- **Event publishing** — `MARKET_SCANNED` event with `asdict(report)`
- **Graceful fallback** — All improvements degrade safely when DataAgent is absent

### ✅ Design Is Valid

The agent does exactly what the architecture describes:

- ✅ Reads symbol lists from config (organized by theme)
- ✅ Returns flat list of symbols (with optional limit)
- ✅ Publishes `MARKET_SCANNED` event for downstream processing
- ✅ Liquidity filtering now implemented
- ✅ Composite ranking now implemented

---

## Integration Example

How the orchestrator uses MarketScannerAgent:

```python
# In MainOrchestratorAgent.handle_market_scan_trigger()

scanner = MarketScannerAgent(config_engine)

# Run scan with live data for ranking/filtering
report = await scanner.run(
    include_themes=None,        # All themes
    min_liquidity=500_000,      # Exclude very illiquid symbols
    limit=10,                   # Top 10 symbols
    data_agent=data_agent       # Enables real liquidity + ranking
)

logger.info(f"Market scan: {report.message}")
# Output: "Market scan: Discovered 10 promising symbols."
# MARKET_SCANNED event fires automatically
# → Orchestrator spawns DataAgent for each symbol
```

---

## Testing

Test suite: `tests/test_market_scanner_agent.py` — **25 tests, all passing**

| Test Class | Tests | Coverage |
|-----------|-------|----------|
| `TestMarketScannerBasics` | 7 | init, themes, symbols, stats |
| `TestThemeScanning` | 3 | scan_theme, scan_all_themes, validate_symbols |
| `TestLiquidityFiltering` | 3 | no threshold, no data agent, with data agent |
| `TestSymbolRanking` | 2 | no data agent (preserves order), with data agent (all returned) |
| `TestMarketScanRun` | 4 | basic, all themes, with limit, limit exceeds symbols |
| `TestWhitelist` | 2 | disabled (all pass), enabled (restrict to whitelist) |
| `TestErrorHandling` | 3 | event bus failure, data fetch failure fallback, empty list |
| `TestIntegration` | 1 | full pipeline: scan → filter → rank → limit |

Run:
```bash
cd /home/eric/.openclaw/workspace/AITradeAgent
source venv/bin/activate
python -m pytest tests/test_market_scanner_agent.py -v
# Expected: 25 passed
```

---

## Summary

**MarketScannerAgent is a fully implemented, configuration-driven symbol discoverer.** It:

- ✅ Selects symbols by theme (5 themes, 25 symbols)
- ✅ Applies optional whitelist restriction
- ✅ Filters by liquidity (average daily volume via DataAgent)
- ✅ Ranks symbols by composite multi-factor score (technical, momentum, value, trend, liquidity)
- ✅ Limits results to configured top N
- ✅ Publishes `MARKET_SCANNED` event

**Pending:** Wiring `data_agent` in the orchestrator (`app.py`) to enable live ranking/filtering in production. Currently runs in graceful-fallback mode.

# AITradeAgent - Current Production Architecture

**Version:** 1.0  
**Last Updated:** 2026-03-29  
**Scope:** Active agents wired into `app.py` orchestrator  
**Status:** Production-ready, fully operational

---

## Quick Summary

**Currently Running:** 13 active agents wired into the orchestrator  
**Core Pipeline:** Market Scan → Data Fetch → (News + Analysis parallel) → Strategy → Risk → Execution → Portfolio + Learning + Health  
**Monitoring Loop:** ExitAgent (every 5 min — reactive exits + strategic re-analysis)  
**Interface:** Telegram bot for commands and notifications

---

## Production Agent Inventory

| # | Agent | Status | Role |
|---|-------|--------|------|
| 1 | MainOrchestratorAgent | ✅ Active | Central coordinator, event router |
| 2 | SchedulerAgent | ✅ Active | Periodic triggers (scan, refresh, reports) |
| 3 | MarketScannerAgent | ✅ Active | Symbol discovery from configured themes |
| 4 | DataAgent | ✅ Active | OHLCV + fundamentals per symbol |
| 5 | NewsAgent | ✅ Active | News sentiment analysis per symbol |
| 6 | AnalysisAgent | ✅ Active | Technical indicators (RSI, MACD, SMAs, ATR) |
| 7 | StrategyAgent | ✅ Active | Rule-based trade proposal generation |
| 8 | RiskAgent | ✅ Active | Risk policy enforcement + approval workflow |
| 9 | ExecutionAgent | ✅ Active | Order submission to broker |
| 10 | PortfolioAgent | ✅ Active | Holdings tracking + P&L calculation |
| 11 | LearningAgent | ✅ Active | Trade outcome analysis + recommendations |
| 12 | HealthAgent | ✅ Active | Monitor system health + Telegram messages |
| — | TelegramAgent | ✅ Active | User interface + notifications |
| 13 | ExitAgent | ✅ Active | Reactive exits + strategic re-analysis (every 5 min) |

---

## Production Event Flow (Current)

```
Trading Pipeline (Daily):
1. SchedulerAgent emits MARKET_SCAN_TRIGGER at market open
   ↓
2. MarketScannerAgent returns list of symbols (e.g., 24 promising stocks)
   ↓
3. Orchestrator spawns DataAgent per symbol (parallel)
   ↓
4. For each symbol, orchestrator spawns:
   • NewsAgent (sentiment analysis)
   • AnalysisAgent (technical indicators)
   in PARALLEL
   ↓
5. When BOTH news + analysis are ready for a symbol:
   → StrategyAgent generates trade proposal
   ↓
6. RiskAgent validates proposal against risk limits
   ↓
7. If auto_execute=true and risks pass:
   → ExecutionAgent submits order
   Else:
   → Telegram approval request sent to user
   ↓
8. On TRADE_EXECUTED:
   → PortfolioAgent updates holdings
   → LearningAgent logs outcome
   → HealthAgent sends Telegram confirmation
   ↓
9. Daily EOD: SchedulerAgent emits DAILY_REPORT_TRIGGER
   → HealthAgent sends portfolio summary to Telegram

Monitoring Loop (Every 5 min):
10. SchedulerAgent emits EXIT_CHECK_TRIGGER
    ↓
11. Orchestrator retrieves portfolio positions from PortfolioAgent
    ↓
12. ExitAgent.run(positions, perform_strategy_check=True):
    • Reactive: checks stop-loss / take-profit triggers
    • Strategic: re-analyzes via AnalysisAgent (RSI, trend)
    ↓
13. If exits triggered → Telegram alert sent
    If degradation detected → POSITION_DEGRADED event emitted
```

---

## Current Agent Descriptions (What's Running)

---

### 1. MainOrchestratorAgent
**File:** `app.py` (lines ~50–450)  
**Status:** ✅ Fully operational

Central event coordinator. Subscribes to all events and routes work to appropriate agents.

**Key responsibilities:**
- Manages per-symbol buffers (waits for both news + analysis before triggering strategy)
- Chains agents in the correct sequence
- Handles all 11 active event subscriptions

**Wired to:** ALL other 11 agents (direct `run()` calls)

---

### 2. SchedulerAgent
**File:** `scheduler_agent.py`  
**Status:** ✅ Active, background loop

Fires periodic triggers throughout the day.

**Currently emits:**
- `MARKET_SCAN_TRIGGER` — typically daily at US market open
- `DATA_REFRESH_TRIGGER` — hourly price refresh for watched symbols
- `DAILY_REPORT_TRIGGER` — end-of-day summary
- `SCHEDULE` — periodic health check tick

---

### 3. MarketScannerAgent
**File:** `market_scanner_agent.py`  
**Status:** ✅ Operational

Discovers promising symbols from configured theme-based lists.

**Current behavior:**
- Reads symbol universe from `finance.yaml` themes (tech, ai, healthcare, hk)
- Checks if US or HK market is currently open
- Returns flat list of symbols (e.g., `["NVDA", "PLTR", "AMD", "700.HK", ...]`)

**Limitation:** No ranking/scoring — all symbols treated equally. (See NEXT_STEPS.md for proposed RankingAgent)

---

### 4. DataAgent
**File:** `data_agent.py`  
**Status:** ✅ Operational

Fetches OHLCV + fundamental data per symbol.

**Current behavior:**
- Default 365-day lookback (ensures SMA200 can be computed)
- Uses configured data provider (OpenBB / Yahoo Finance / IBKR)
- Caches results to avoid redundant API calls
- Normalizes data format across providers

---

### 5. NewsAgent
**File:** `news_agent.py`  
**Status:** ✅ Operational

Analyzes news sentiment for symbols.

**Current behavior:**
- Fetches recent news articles per symbol
- Sentiment analysis: bullish / bearish / neutral
- Returns sentiment score (0.0 to 1.0)
- Identifies catalysts if available

---

### 6. AnalysisAgent
**File:** `analysis_agent.py`  
**Status:** ✅ Operational

Computes technical indicators from OHLCV data.

**Current indicators:**
- RSI (14-period)
- MACD + signal line
- SMA 20, 50, 200
- ATR (volatility)
- Bollinger Bands
- Trend classification (bullish/bearish/neutral)

---

### 7. StrategyAgent
**File:** `strategy_agent.py`  
**Status:** ✅ Operational

Generates BUY/SELL/HOLD proposals based on rule-based strategy.

**Current behavior:**
- Evaluates `RuleStrategy` rules against indicator values
- Combines technical signals + news sentiment
- Checks portfolio to avoid duplicate positions
- Calculates confidence score, entry, stop-loss, take-profit
- Returns proposals only if confidence > `confidence_threshold` (default 0.70)

---

### 8. RiskAgent
**File:** `risk_agent.py`  
**Status:** ✅ Operational

Enforces risk management policies.

**Current checks:**
- Max position size per symbol (e.g., 10% of portfolio)
- Max total portfolio exposure (e.g., 80%)
- Max portfolio drawdown tolerance (e.g., 15%)
- Duplicate position check
- Sector concentration limits

**Output:**
- `RISK_CHECK_COMPLETE` — all checks passed, safe to execute
- `APPROVAL_REQUIRED` — requires human Telegram approval
- `RISK_ALERT` — limit breach warning

---

### 9. ExecutionAgent
**File:** `execution_agent.py`  
**Status:** ✅ Operational

Submits orders to configured broker.

**Current brokers supported:**
- `paper` — simulated paper trading (default for dev/testing)
- `alpaca` — live equity trading
- `ibkr` — live trading via Interactive Brokers

**Current behavior:**
- Takes approved trade from RiskAgent
- Submits order to broker
- Returns fill price, order ID, status

---

### 10. PortfolioAgent
**File:** `portfolio_agent.py`  
**Status:** ✅ Operational

Maintains portfolio state and metrics.

**Current capabilities:**
- Tracks open positions (symbol, quantity, entry price, stop-loss, take-profit)
- Updates positions on each execution
- Calculates P&L metrics (total equity, cash, position P&L, return %)
- Serves as single source of truth for holdings
- Responds to `GET_PORTFOLIO_STATE` queries from Telegram

---

### 11. LearningAgent
**File:** `learning_agent.py`  
**Status:** ✅ Operational

Analyzes trade outcomes to identify patterns.

**Current metrics tracked:**
- Win rate (% of profitable trades)
- Avg return % per trade
- Total trades executed
- Sharpe ratio
- Detects winning vs losing trade patterns

**Output:**
- Recommendations for strategy adjustments
- Flags parameter adjustments if needed

---

### 12. HealthAgent
**File:** `health_agent.py`  
**Status:** ✅ Operational

Monitors system health and sends Telegram notifications.

**Current responsibilities:**
- Live portfolio health metrics
- Anomaly detection (unusual drawdown, stale data)
- Trade confirmation messages to Telegram
- Daily P&L summary reports
- System status replies to `/status` command

---

### 13. ExitAgent
**File:** `exit_agent.py`  
**Status:** ✅ Operational (wired via `EXIT_CHECK_TRIGGER` every 5 min)

Monitors held positions for exit conditions and strategic degradation.

**Dual-mode operation:**
- **Reactive exits:** Checks stop-loss (`current_price ≤ stop_loss_price`) and take-profit (`current_price ≥ take_profit_price`)
- **Strategic re-analysis:** Fetches fresh data, runs AnalysisAgent, flags if RSI > 70 (overbought) or trend is bearish

**Integration flow:**
- SchedulerAgent → `EXIT_CHECK_TRIGGER` → Orchestrator → `PortfolioAgent.get_positions()` → `ExitAgent.run()` → Telegram alerts

---

### 14. TelegramAgent
**File:** `telegram_agent.py`  
**Status:** ✅ Operational, always listening

User interface via Telegram bot.

**Current commands:**
- `/start` — Welcome message
- `/status` — Show all agent statuses
- `/portfolio` — Show current holdings + equity

**Automatic messages sent by system:**
- Market scan summaries
- Trade confirmations (via HealthAgent)
- Daily P&L reports
- Approval requests (when APPROVAL_REQUIRED)
- Error alerts

---

## Production Configuration

**Key settings in `finance.yaml`:**

```yaml
finance:
  execution:
    broker: paper              # Currently set to paper trading

  risk:
    max_position_pct: 0.10    # 10% max per symbol
    max_total_exposure_pct: 0.80  # 80% max total
    max_drawdown_pct: 0.15    # Halt at 15% drawdown

  strategy:
    auto_execute:
      enabled: false          # Requires Telegram approval
    confidence_threshold: 0.70  # Minimum 70% confidence

  scanner:
    themes:
      - tech                  # US tech stocks
      - ai                    # AI-focused stocks
      - healthcare            # Healthcare sector
      - hk                    # Hong Kong stocks
```

---

## Daily Workflow

```
Morning (Market Open):
└─ SchedulerAgent fires MARKET_SCAN_TRIGGER
└─ MarketScannerAgent scans (e.g., finds 24 symbols)
└─ DataAgent fetches OHLCV for each (parallel)
└─ NewsAgent + AnalysisAgent run per-symbol (parallel)
└─ StrategyAgent generates proposals (when both news + analysis ready)
└─ RiskAgent validates proposals
└─ ExecutionAgent submits approved orders (or waits for Telegram approval)
└─ PortfolioAgent updates holdings
└─ LearningAgent logs outcomes
└─ HealthAgent sends Telegram notification

Throughout Day:
└─ SchedulerAgent emits EXIT_CHECK_TRIGGER (every 5 min)
└─ ExitAgent checks all held positions:
   └─ Reactive: stop-loss / take-profit checks
   └─ Strategic: re-analysis via AnalysisAgent (RSI, trend)
└─ Telegram alerts for any exits or degraded positions
└─ SchedulerAgent emits DATA_REFRESH_TRIGGER (hourly)
└─ DataAgent refreshes prices for watched symbols

End of Day (Market Close):
└─ SchedulerAgent fires DAILY_REPORT_TRIGGER
└─ HealthAgent compiles portfolio metrics
└─ TelegramAgent sends daily P&L summary
```

---

## Known Limitations (Current Production)

| Issue | Impact | Status |
|-------|--------|--------|
| ~~ExitAgent not wired~~ | ✅ ExitAgent wired — runs every 5 min for reactive exits + strategic re-analysis | Completed |
| Approval workflow mocked | Auto-approval for testing | ✅ By design |
| Continuous position monitoring | ✅ ExitAgent runs every 5 min | Reactive (stops/profits) + Strategic (degradation checks) |
| Single theme per scan | Must configure one theme at a time | Config limitation |

---

## Comparison: Current vs. Proposed

| Feature | Current | Proposed |
|---------|---------|----------|
| Active agents | 13 (including ExitAgent) | Fully operational |
| Symbol discovery | Flat list | Ranked by score |
| Exit management | ✅ Automated (ExitAgent every 5 min) | Reactive + strategic |
| Risk checks | 5 policies | Potential expansion |
| Data providers | OpenBB/Yahoo/IBKR | (Extensible) |

---

## How to Use This Document

- **For operations:** Follow the "Daily Workflow" section
- **For troubleshooting:** Check "Known Limitations"
- **For development:** See AGENT_ARCHITECTURE.md for full system design including proposed enhancements
- **For roadmap:** See NEXT_STEPS.md for planned additions (ExitAgent wiring, RankingAgent, etc.)

---

## Files Reference

| Purpose | File |
|---------|------|
| **This file** | `CURRENT_ARCHITECTURE.md` (production state) |
| **Full design** | `AGENT_ARCHITECTURE.md` (comprehensive, all agents + proposed) |
| **Roadmap** | `NEXT_STEPS.md` (planned enhancements) |
| **Code** | `finance_service/app.py` (orchestrator) |
| **Config** | `finance.yaml` (all settings) |

# SchedulerAgent - Specification & Design

**Agent ID:** `scheduler_agent`  
**File:** `finance_service/agents/scheduler_agent.py`  
**Status:** ✅ Production-ready, actively used  
**Version:** 1.0  
**Last Updated:** 2026-03-29

---

## Overview

SchedulerAgent triggers periodic events at configured intervals. It runs as a background task started at service boot and publishes scheduled **events** to the EventBus. It is the **timekeeper** of the system.

**Key Responsibility:** Automate periodic tasks (market scan, health checks, daily reports).

---

## Design Philosophy

```
                    ┌─────────────────────────────────┐
                    │  SchedulerAgent.run()            │
                    │  - Start asyncio tasks          │
                    │    with fixed intervals         │
                    └──────────────┬──────────────────┘
                                   │
                    ┌──────────────▼─────────────────┐
                    │  Periodic Event Publishing     │
                    │  - MARKET_SCAN_TRIGGER         │
                    │    (every 15 min)              │
                    │  - EXIT_CHECK_TRIGGER          │
                    │    (every 5 min)               │
                    │  - DATA_REFRESH_TRIGGER        │
                    │    (every 30 min)              │
                    │  - SCHEDULE (health check)     │
                    │    (every 4 h)                 │
                    │  - DAILY_REPORT_TRIGGER        │
                    │    (once per day)              │
                    └─────────────────────────────────┘
```

---

## Initialization & Startup

In `app.py` startup:
```python
scheduler_agent = SchedulerAgent(config={})
orchestrator.scheduler_agent = scheduler_agent
asyncio.create_task(scheduler_agent.run())
```

The `run()` method schedules tasks and then returns an `AgentReport` indicating success; the actual scheduling loops run as background `asyncio.Task`s.

---

## Scheduled Tasks

| Task Name | Interval | Event Published | Description |
|-----------|----------|-----------------|-------------|
| `market_scan` | Every 15 minutes | `MARKET_SCAN_TRIGGER` | Starts the symbol scanning pipeline |
| `exit_check` | Every 5 minutes | `EXIT_CHECK_TRIGGER` | Triggers ExitAgent position monitoring (reactive + strategic) |
| `data_refresh` | Every 30 minutes | `DATA_REFRESH_TRIGGER` | Placeholder for periodic data warming (currently unused) |
| `health_check` | Every 4 hours | `SCHEDULE` | Triggers `HealthAgent.perform_health_check()` |
| `daily_report` | Once per day (midnight) | `DAILY_REPORT_TRIGGER` | Triggers daily summary after market close |

---

## Configuration (finance.yaml)

```yaml
finance:
  scheduler:
    market_scan_interval_minutes: 15
    data_refresh_interval_minutes: 30
    health_check_interval_hours: 4
    daily_report_trigger_time: "00:00"  # HH:MM (local time UTC+8? not yet timezone-aware)
```

Currently, the intervals are hard‑coded in `_schedule_task` calls. Future: read these from config.

---

## Implementation Details

### `_schedule_task(task_name, coro, interval)`

- Wraps the coroutine in an infinite loop.
- Catches exceptions and logs them.
- Sleeps `interval.total_seconds()` between runs.
- Stores the `asyncio.Task` in `self.scheduled_tasks`.
- On restart, any existing task for that name is cancelled before creating a new one.

### Trigger Methods

- `_trigger_daily_market_scan()` → `Event(MARKET_SCAN_TRIGGER)`
- `_trigger_exit_check()` → `Event(EXIT_CHECK_TRIGGER, data={"interval": "5min"})`
- `_trigger_hourly_data_refresh()` → `Event(DATA_REFRESH_TRIGGER)`
- `_trigger_health_check()` → `Event(SCHEDULE, data={})`
- `_trigger_daily_report()` → `Event(DAILY_REPORT_TRIGGER)`

These are called by the background loops.

---

## Stopping

`await scheduler_agent.stop()` cancels all background tasks and waits for them to finish. Called on service shutdown.

---

## Event Flow Integration

```
Scheduler background loop (every 15 min)
    ↓
Publish MARKET_SCAN_TRIGGER
    ↓
Orchestrator.handle_market_scan_trigger() runs scanner, etc.
```

---

## Error Handling

- Exceptions inside a scheduled task are logged; the loop continues and sleeps before next run.
- If a coroutine raises `CancelledError` (during stop), the task exits cleanly.

---

## Testing

Test suite: `tests/test_scheduler_agent.py` likely tests:
- Task scheduling and cancellation
- Event publication timing (using time mocking)

Run:
```bash
cd /home/eric/.openclaw/workspace/AITradeAgent
source venv/bin/activate
python -m pytest tests/test_scheduler_agent.py -v
```

---

## Notes

- SchedulerAgent does **not** consider market hours; it publishes triggers regardless. Downstream agents (e.g., `is_market_open()` checks in orchestrator) may skip processing on weekends/after hours.
- Daily report timing uses `timedelta(days=1)` with an initial run at startup then every 24h; a real implementation would calculate until next midnight.
- This agent is minimal but effective; could be replaced by a more sophisticated scheduler (e.g., APScheduler) if needed.

---

**Summary:** SchedulerAgent runs periodic background loops that publish events to drive the system. It is the metronome ensuring regular scans, health checks, and summaries.
